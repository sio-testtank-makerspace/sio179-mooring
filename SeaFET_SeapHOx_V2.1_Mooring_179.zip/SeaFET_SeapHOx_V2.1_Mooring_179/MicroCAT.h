/*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 */
#ifndef SEAFET_SEAPHOX_V2_0_MICROCAT_H_
#define SEAFET_SEAPHOX_V2_0_MICROCAT_H_



/*
 * MicroCAT.c function prototypes:
 */
void Init_MicroCAT(void);
void openMicroCAT(void);
void pollMicroCAT(void);
void closeMicroCAT(void);


void parseMicroCATData(void);

extern void MicroCAT_UARTConfig(uint32_t ui32Port, uint32_t ui32Baud,
                            uint32_t ui32SrcClock);
extern int MicroCAT_UARTgets(char *pcBuf, uint32_t ui32Len);
extern unsigned char MicroCAT_UARTgetc(void);
extern int MicroCAT_UARTwrite(const char *pcBuf, uint32_t ui32Len);
extern int MicroCAT_UARTPeek(unsigned char ucChar);
extern void MicroCAT_UARTFlushTx(bool bDiscard);
extern void MicroCAT_UARTFlushRx(void);
extern int MicroCAT_UARTRxBytesAvail(void);
extern int MicroCAT_UARTTxBytesFree(void);
extern void MicroCAT_UARTEchoSet(bool bEnable);

extern int MicroCAT_putc(const char c);

#endif /* SEAFET_SEAPHOX_V2_0_MICROCAT_H_ */



