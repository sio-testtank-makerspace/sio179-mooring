/*
 * Init.c
 *
 *  Created on: Jan 23, 2014
 *      Author: rob
 */

#include "System.h"
#include "Init.h"
#include "SDCard.h"
#include "uartstdio.h"	// User local version with larger RX buffer
#include "sleep.h"

/**********************************************************************************
 * Init()
 * Initialize pins and ports upon reset or wake from hybernation. Set unused pins low.
 **********************************************************************************/
void Init(void)
{
	// Enable lazy stacking for interrupt handlers.  This allows floating-point
	// instructions to be used within interrupt handlers, but at the expense of2
	// extra stack usage.
	ROM_FPULazyStackingEnable();

	//enable floats
	ROM_FPUEnable();

	//set the system clock...50MHZ
	ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);

	/*** Enable the GPIO ports used ***/
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOP);

	/*** Initialize the console ***/
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
	ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
	ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
	UARTStdioConfig(0, 115200, 16000000);		// 115200 bits per second

	// CONSOLE_ON pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_0);
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_0, 0xff);		// Set pin to turn console driver on

	UARTEchoSet(true);	// Enable console echo


	ROM_SysCtlDelay(MILLISECOND*100);
//	uprintf("\n\nConsole initialized");

	/*** Retrieve saved sys_data variables ***/
	retrieveSysDataVariables();


	/*** Initialize isolated ADS1248 pins as GPIO to reduce power consumption ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_0);		// SSI3CLK
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_0, 0x00);

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_1);		// SSI3Fss
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_1, 0x00);

	ROM_GPIOPinTypeGPIOInput(GPIO_PORTH_BASE, GPIO_PIN_2);		// SSI3Rx

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_3);		// SSI3Tx
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_3, 0x00);

	// START pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_7);
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_7, 0x00);		// Clear pin

	// DRDY pin
	ROM_GPIOPinTypeGPIOInput(GPIO_PORTN_BASE, GPIO_PIN_3);		// Input

	// RESET pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_5);
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, 0x00);		// Clear pin

	// Isolated power
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_2);
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_2, 0x00);  		// Iso-power Off

	// Optoisolator power
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_4);
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_4, 0x00);  		// Optoisolator power Off



	/*** Initialize non-isolated ADS1248 on SSI1 ***/
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI1);  // Enable SSI1

	ROM_GPIOPinConfigure(GPIO_PF1_SSI1TX);
	ROM_GPIOPinConfigure(GPIO_PD2_SSI1RX);
	ROM_GPIOPinConfigure(GPIO_PF2_SSI1CLK);
	ROM_GPIOPinConfigure(GPIO_PF3_SSI1FSS);

	// Configure the GPIO pins as SSI.
	ROM_GPIOPinTypeSSI(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
	ROM_GPIOPinTypeSSI(GPIO_PORTD_BASE, GPIO_PIN_2);

	// Configure and enable the SSI port for SPI master mode.
	ROM_SSIConfigSetExpClk(SSI1_BASE, ROM_SysCtlClockGet(), SSI_FRF_MOTO_MODE_1, SSI_MODE_MASTER, 1000000, 8); 	// MOTO_MODE_1
	ROM_SSIEnable(SSI1_BASE);

	// Set up the DRDY pin
	ROM_GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_5);	// Input

	// Set up RESET pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_6);
	ROM_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_6, 0xff);	// Deassert RESET (high)

	// Set up START pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_7);
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_7, 0x0);		// Set START low

	//  Set up ADS1248 power pin
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_4);
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_4, 0x00);	// Power off


	/*** Initialize MicroCAT on UART 4 ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0); // MicroCAT power (PD0, pin 1)
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, 0x00);	// Power off MicroCAT

	// MicroCAT UART PWRDWN (PK3, pin 19)
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_3);
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_3, 0x00);	// Shut off COM 1 driver

	// Set up MicroCAT UART
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART4);
	ROM_GPIOPinConfigure(GPIO_PC4_U4RX);
	ROM_GPIOPinConfigure(GPIO_PC5_U4TX);
	ROM_GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5);

    // Use the internal 16MHz oscillator as the UART clock source.
    UARTClockSourceSet(UART4_BASE, UART_CLOCK_PIOSC);

    MicroCAT_UARTConfig(4, 9600, 16000000); // Configure UART  (9600,N,8,1)
 	MicroCAT_UARTEchoSet(0);	// Disable echo to MicroCAT


 	/*** Inititialize Optode on UART 3 ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1);	// Optode power (PD1, pin 2)
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, 0x00);	// Power off

	// set up UART to the optode
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
	ROM_GPIOPinConfigure(GPIO_PC6_U3RX);
	ROM_GPIOPinConfigure(GPIO_PC7_U3TX);
	ROM_GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_6 | GPIO_PIN_7);

    // Use the internal 16MHz oscillator as the UART clock source.
    UARTClockSourceSet(UART3_BASE, UART_CLOCK_PIOSC);

    Optode_UARTConfig(3, 9600, 16000000); // Configure UART  (9600,N,8,1)
 	Optode_UARTEchoSet(0);	// Disable echo to Optode


 	/*** Initialize Pump ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_3);	// Pump power (PD3, pin 4)
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_3, 0x00);	// Pump off


	/*** Initialize pressure sensor ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_5);
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_5, 0x00);  	// Pressure sensor off

	/*** Inititialize AUX1 on UART 2 ***/
	MAP_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_4);	// AUX1 power
	MAP_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_4, 0x00);	// Power off

	// COM2 PWRDOWN (PK4, pin 112) pin
	MAP_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_4);
	MAP_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_4, 0x00);	// Shut off COM2 driver

	// Set up AUX1 UART pins
	MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART2);
	MAP_GPIOPinConfigure(GPIO_PG4_U2RX);			  // Set up the pins
	MAP_GPIOPinConfigure(GPIO_PG5_U2TX);
	MAP_GPIOPinTypeUART(GPIO_PORTG_BASE, GPIO_PIN_5 | GPIO_PIN_4);

    // Use the internal 16MHz oscillator as the UART clock source.
    UARTClockSourceSet(UART2_BASE, UART_CLOCK_PIOSC);

    // Initialize UART 2
    AUX1_UARTConfig(2, 9600, 16000000);


	/*** Initialize AUX2 on UART 5 ***/
	MAP_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_7);
	MAP_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_7, 0x00);	// Power off

	// Set up AUX2 UART pins
	MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART5);
	MAP_GPIOPinConfigure(GPIO_PJ2_U5RX);			  // Set up the pins
	MAP_GPIOPinConfigure(GPIO_PJ3_U5TX);
	MAP_GPIOPinTypeUART(GPIO_PORTJ_BASE, GPIO_PIN_2 | GPIO_PIN_3);

    // Use the internal 16MHz oscillator as the UART clock source.
    UARTClockSourceSet(UART5_BASE, UART_CLOCK_PIOSC);

	// Initialize the UART
    AUX2_UARTConfig(5, 9600, 16000000);


    /*** Initialize Green LED ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_3);	// Green LED (PE3, pin 12)
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_3, 0x00);	// LED off


	/*** Initialize Red LED ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTP_BASE, GPIO_PIN_2);	// Red LED (PP2, pin 11)
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_2, 0x00);	// LED off


    /*** Initialize the DIC port ***/
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_6);	// PD6, pin 143
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_4);	// PE4, pin 139
	ROM_GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_5);	// PE5, pin 140
	ROM_GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_6);	// PE6, pin 133
	ROM_GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_7);	// PE7, pin 134
	ROM_GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_7, 0x00);	// Clear

	// Temporarily Setup unused ports as GPIO (change this if I2C, SSI2, or M0PWM used)
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_4);	// PH4, pin 26
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_4, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_5);	// PH5, pin 23
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_6);	// PH6, pin 22
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_7);	// PH7, pin 21
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2);	// PB2, pin 99
	ROM_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, 0xFF);	// Set (R62 pull up)

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_3);	// PH3, pin 100
	ROM_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, 0xFF);	// Set (R63 pull up)

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTP_BASE, GPIO_PIN_0);	// PP0, pin 131
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTP_BASE, GPIO_PIN_1);	// PP1, pin 132
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, 0x00);	// Clear


    // Initialize unused pins
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);	// PA6, pin 45
	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_7);	// PA7, pin 46
	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_0);	// PB0, pin 97
	ROM_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_1);	// PB1, pin 98
	ROM_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_4);	// PB4, pin 136
	ROM_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_4, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_5);	// PD5, pin 142
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_7);	// PD7, pin 144
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_0);	// PG0, pin 55
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_1);	// PG1, pin 54
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_2);	// PG2, pin 53
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_2, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_3);	// PG3, pin 52
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_3, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_6);	// PG6, pin 48
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTG_BASE, GPIO_PIN_7);	// PG7, pin 47
	ROM_GPIOPinWrite(GPIO_PORTG_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_0);	// PJ0, pin 120
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_1);	// PJ1, pin 121
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_4);	// PJ4, pin 127
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_4, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_5);	// PJ5, pin 128
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_6);	// PJ6, pin 129
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_7);	// PJ7, pin 130
	ROM_GPIOPinWrite(GPIO_PORTJ_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_0);	// PK0, pin 16
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_1);	// PK1, pin 17
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_5);	// PK5, pin 111
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_6);	// PK6, pin 110
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_7);	// PK7, pin 109
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_7, 0x00);	// Clear

//	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_0);	// PL0, pin 108
//	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_1);	// PL1, pin 107
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_2);	// PL2, pin 106
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_2, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_3);	// PL3, pin 105
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_3, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_4);	// PL4, pin 104
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_4, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_5);	// PL5, pin 103
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_5, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_6);	// PL6, pin 96
	ROM_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_0);	// PM0, pin 89
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_1);	// PM1, pin 88
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_2);	// PM2, pin 87
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_2, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_3);	// PM3, pin 86
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_3, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_6);	// PM6, pin 83
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_6, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_7);	// PM7, pin 82
	ROM_GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_7, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);	// PN0, pin 81
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);	// PN1, pin 80
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, 0x00);	// Clear

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_2);	// PN2, pin 20
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_2, 0x00);	// Clear

	/*** Configure SysTick for a 100Hz interrupt.  The FatFs driver and 10 ms timer share a 10 ms tick ***/
	ROM_SysTickPeriodSet(ROM_SysCtlClockGet() / 100);
	ROM_SysTickEnable();
	ROM_SysTickIntEnable();

	// Find out what woke us and decide what to do
	sleep_handler();

	// Initialize MicroSD card and FatFs
	Init_SDCard();
}



