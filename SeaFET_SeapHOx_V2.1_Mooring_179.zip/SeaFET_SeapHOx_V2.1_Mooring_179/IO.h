/*
 * IO.h
 *
 * Input/Output functions used mostly by console port.
 *
 *  Created on: Jan 23, 2014
 *      Author: rob
 */

#ifndef SEAFET_SEAPHOX_V2_0_IO_H_
#define SEAFET_SEAPHOX_V2_0_IO_H_

#define YES				  		1
#define NO				  		0
#define TIMELIMITPASSED  		-1

void ConfigureUART(void);
void printCurrentTime(void);
void print_time_t_Time(time_t time);
int yesOrNoMenuChoice(char *prompt, int default_response);
int yesOrNoMenuChoiceTimeLimit(char *prompt, int timeLimit);
int getUserInput(char *userInputBuffer,  int userInputBufferSize);
int getUserInputTimeLimit(char *userInputBuffer, int userInputBufferSize, int timeLimit);
void printSysDataParameters();
time_t getDateAndTime();
int32_t getLong(char *prompt);
uint32_t getUnsignedLong (char* prompt);
float getFloat(char *prompt);
void ftoa(long double f,char *buf,int dplaces);
int getchar_timed(int timeout);
int uprintf(const char *format, ...);
bool kbhit(void);
char get_key(void);

#endif /* SEAFET_SEAPHOX_V2_0_IO_H_ */
