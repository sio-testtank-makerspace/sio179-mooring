/*
 * Aux2.h
 *
 *  Created on: Feb 4, 2014
 *      Author: rob
 */

#ifndef SEAFET_SEAPHOX_V2_0_AUX2_H_
#define SEAFET_SEAPHOX_V2_0_AUX2_H_

// Macros
#define AUX2_on() 	MAP_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_7, 0xff);	// Power on
#define AUX2_off() 	MAP_GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_7, 0x00);	// Power off

//*****************************************************************************
//
// Prototypes for the APIs.
//
//*****************************************************************************
extern void Init_AUX2(void);
extern void Open_AUX2(void);
extern void Close_AUX2(void);
extern void AUX2_UARTConfig(uint32_t ui32Port, uint32_t ui32Baud,
                            uint32_t ui32SrcClock);
extern int AUX2_UARTgets(char *pcBuf, uint32_t ui32Len);
extern unsigned char AUX1_UARTgetc(void);
extern int AUX2_UARTwrite(const char *pcBuf, uint32_t ui32Len);
extern int AUX2_UARTPeek(unsigned char ucChar);
extern void AUX2_UARTFlushTx(bool bDiscard);
extern void AUX2_UARTFlushRx(void);
extern int AUX2_UARTRxBytesAvail(void);
extern int AUX2_UARTTxBytesFree(void);
extern void AUX2_UARTEchoSet(bool bEnable);



#endif /* SEAFET_SEAPHOX_V2_0_AUX2_H_ */
