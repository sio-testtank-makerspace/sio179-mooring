/*
 * SeapHOx.h
 *
 *  Created on: Jan 9, 2014
 *      Author: rob
 *
 * SeapHOx controller system-wide include files and definitions
 */

#ifndef SEAPHOX_H_
#define SEAPHOX_H_

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <ctype.h>


#include "inc/tm4c123gh6pge.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_hibernate.h"

#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/eeprom.h"
#include "driverlib/gpio.h"
#include "driverlib/hibernate.h"
#include "driverlib/ssi.h"
#include "driverlib/interrupt.h"

#define 	VERSION		"2v1"		// SeapHOx software version

/* Boolean type */
typedef enum { FALSE = 0, TRUE } BOOL;


/*
 * Possible deployment states.
 */
typedef enum
{
 SAMPLING_IMMEDIATELY_UPON_DEPLOYMENT = 1,   //deployed the SeapHOX without indicating a specific time to start sampling (so, we're taking a sample immediately)
 TS_ON_TIME_MATCH =						2,   //woke up by a RTC time match, taking a sample
 TS_COMMAND = 							3,   //woke up by the wake pin, taking a sample
 GDATA_COMMAND =						4,   //woke up by the wake pin, issued gdata command
 NO_VALID_COMMAND_RECEIVED	=			5   //we woke up by the wake pin, but did not receive a valid command
}deploymentStates;

#endif /* SEAPHOX_H_ */
