/*
 * Sleep.h
 *
 *  Created on: Jan 24, 2014
 *      Author: rob
 */

#ifndef SEAFET_SEAPHOX_V2_0_SLEEP_H_
#define SEAFET_SEAPHOX_V2_0_SLEEP_H_

void sleep(deploy_state state, uint32_t wake_time);
void sleep_handler(void);

#endif /* SEAFET_SEAPHOX_V2_0_SLEEP_H_ */
