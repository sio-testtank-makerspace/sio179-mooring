 /*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 */

#ifndef SEAFET_SEAPHOX_V2_0_OPTODE_H_
#define SEAFET_SEAPHOX_V2_0_OPTODE_H_



/*
 * Optode.c function prototypes:
 */
void Init_Optode(void);
void openOptode(void);
void pollOptode(void);
void closeOptode(void);

void parseOptodeData(void);

extern void Optode_UARTConfig(uint32_t ui32Port, uint32_t ui32Baud,
                            uint32_t ui32SrcClock);
extern int Optode_UARTgets(char *pcBuf, uint32_t ui32Len);
extern unsigned char Optode_UARTgetc(void);
extern int Optode_UARTwrite(const char *pcBuf, uint32_t ui32Len);
extern int Optode_UARTPeek(unsigned char ucChar);
extern void Optode_UARTFlushTx(bool bDiscard);
extern void Optode_UARTFlushRx(void);
extern int Optode_UARTRxBytesAvail(void);
extern int Optode_UARTTxBytesFree(void);
extern void Optode_UARTEchoSet(bool bEnable);
extern int Optode_putc(const char c);



#endif /* SEAFET_SEAPHOX_V2_0_OPTODE_H_ */
