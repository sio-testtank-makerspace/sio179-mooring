/*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 * rglatts@ucsd.edu
 */

#ifndef SEAFET_SEAPHOX_V2_0_ADS1248_ISO_H_
#define SEAFET_SEAPHOX_V2_0_ADS1248_ISO_H_

/*
 * Isolated ADS1248 function prototypes:
 */
void Init_ADS1248_iso(void);
void openADS1248_iso(void);
float pollADS1248_iso(unsigned char pos_chan, unsigned char neg_chan, int trials, int gain, int sps);
void closeADS1248_iso(void);

#endif
