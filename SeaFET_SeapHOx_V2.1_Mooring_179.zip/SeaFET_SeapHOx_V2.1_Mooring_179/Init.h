/*
 * Init.h
 *
 *  Created on: Jan 23, 2014
 *      Author: rob
 */

#ifndef SEAFET_SEAPHOX_V2_0_INIT_H_
#define SEAFET_SEAPHOX_V2_0_INIT_H_

#include "System.h"
#include "ADS1248_iso.h"
#include "ADS1248_noniso.h"
#include "MicroCAT.h"
#include "Optode.h"
#include "AUX1.h"
#include "AUX2.h"

void Init(void);
void Init_Pump();
void Init_Pressure(void);
void Init_AUX(void);
void Init_LED(void);
void Init_DIC(void);
void Init_Unused(void);


#endif /* SEAFET_SEAPHOX_V2_0_INIT_H_ */
