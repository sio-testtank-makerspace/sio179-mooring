/*
 * Aux_port.h
 *
 *  Created on: Feb 4, 2014
 *      Author: rob
 */

#ifndef AUX1_PORT_H_
#define AUX1_PORT_H_

// Macros
#define AUX1_on() 	MAP_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_4, 0xff);	// Power on
#define AUX1_off() 	MAP_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_4, 0x00);	// Power off


//*****************************************************************************
//
// Prototypes for the APIs.
//
//*****************************************************************************
extern void Init_AUX1(void);
extern void Open_AUX1(void);
extern void Close_AUX1(void);
extern void AUX1_UARTConfig(uint32_t ui32Port, uint32_t ui32Baud,
                            uint32_t ui32SrcClock);
extern int AUX1_UARTgets(char *pcBuf, uint32_t ui32Len);
extern unsigned char AUX1_UARTgetc(void);
extern int AUX1_UARTwrite(const char *pcBuf, uint32_t ui32Len);
extern int AUX1_UARTPeek(unsigned char ucChar);
extern void AUX1_UARTFlushTx(bool bDiscard);
extern void AUX1_UARTFlushRx(void);
extern int AUX1_UARTRxBytesAvail(void);
extern int AUX1_UARTTxBytesFree(void);
extern void AUX1_UARTEchoSet(bool bEnable);


#endif /* AUX1_PORT_H_ */
