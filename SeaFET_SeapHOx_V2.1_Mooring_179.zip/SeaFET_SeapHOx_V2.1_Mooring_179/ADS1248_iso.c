/*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 */


/*
 * ADS1248_iso.c
 * Driver library for isolated ADS1248.
 */

#include "System.h"
#include "ADS1248_iso.h"
#include "System.h"
#include "uartstdio.h"	// User local version with larger RX buffer
#include "IO.h"


#define PGA        	1
#define SDATAC 		0x16	// Stop reading data continuously command for ADS1248
#define RDATA  		0x12    // Read data command
#define RDATAC 		0x14	// Start reading data continuously
#define NOP 		0xFF    // No operation command
#define SELFOCAL 	0x62   	// Self offset calibration command

// ADS1248 Register macros
#define REG_MUX0    0x0
#define REG_VBIAS   0x1
#define REG_MUX1    0x2
#define REG_SYS0    0x3
#define REG_OFC0    0x4
#define REG_OFC1    0x5
#define REG_OFC2    0x6
#define REG_FSC0    0x7
#define REG_FSC1    0x8
#define REG_FSC2    0x9
#define REG_IDAC0   0xa
#define REG_IDAC1   0xb
#define REG_GPIOCFG 0xc
#define REG_GPIODIR 0xD
#define REG_GPIODAT 0xE

// Function macros
#define iso_DRDY() 			ROM_GPIOPinRead(GPIO_PORTN_BASE, GPIO_PIN_3)
#define iso_assert_CS()		ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_1, 0x00);	// Assert chip select (set low)
#define iso_deassert_CS()	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_1, 0xff);	// Deassert chip select (set high)
#define iso_START_high()	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_6, 0x00);	// Inverted due to optoisolator
#define iso_START_low()		ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_6, 0xff);	// Inverted due to optoisolator
#define iso_RESET_high()	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, 0x00);	// Inverted due to optoisolator
#define iso_RESET_low()		ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, 0xff);	// Inverted due to optoisolator

/*
 * ADS1248 Delays
 */
//205ms delay. At default 5SPS, digital filter reset takes about 200ms
#define SPS5DELAY (MILLISECOND * 205)

//55ms delay. At 20SPS, digital filter reset takes about 50ms
#define SPS20DELAY (MILLISECOND * 55)

//805ms delay. At 20SPS, calibration takes about 801ms
#define SPS20CALIBRATIONDELAY (MILLISECOND * 805)

// Local function prototypes
unsigned char ADS1248_gain_sps(int gain, int sps);

/*
 * openADS1248_iso()
 * Performs initial set up of the isolated ADS1248.
 * Note that SSI3FSS is configured to toggle chip select manually.
 * This is needed as ADS1248 requires CS to stay low during complete
 * SSI register transactions.
 */

void openADS1248_iso(void)
{
	// Power up
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_2, 0xff);	// Iso 3.3V power on
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_4, 0xff);  	// Optoisolator power on
	ROM_SysCtlDelay(MILLISECOND*25);						// Let things settle

	// Setup SSI port 3
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI3);
	ROM_GPIOPinConfigure(GPIO_PH2_SSI3RX);
	ROM_GPIOPinConfigure(GPIO_PH3_SSI3TX);
	ROM_GPIOPinConfigure(GPIO_PH0_SSI3CLK);
	ROM_GPIOPinTypeSSI(GPIO_PORTH_BASE, GPIO_PIN_0 | GPIO_PIN_2 | GPIO_PIN_3);

	iso_deassert_CS();

	// Configure and enable SSI for SPI master mode.
	ROM_SSIConfigSetExpClk(SSI3_BASE, ROM_SysCtlClockGet(), SSI_FRF_MOTO_MODE_1,	SSI_MODE_MASTER, 1000000, 8);	//MOTO_MODE_1
	ROM_SSIEnable(SSI3_BASE);

	iso_START_high();	// START high

	//tie reset high
	iso_RESET_high();

	// Wait for ADS1248 clock initialization to complete
	ROM_SysCtlDelay(MILLISECOND*25);

	// Pulse TPS3836 Manual Reset (/MR) low, which immediately pulses ADS1248 RESET low
	iso_RESET_low();
	ROM_SysCtlDelay(MILLISECOND * 2);  // Keep RESET low for 2 ms
	iso_RESET_high();

	// SPI communication can begin > 0.6 ms after TPS3836 RESET pulse...
	ROM_SysCtlDelay(MILLISECOND * 2);
}


/*
 * closeADS1248()
 * Clears uP output pins for low power.
 * Shuts of power to optoisolators and ADS1248 analog supply.
 */
void closeADS1248_iso(void)
{
	iso_START_high();			// Pin cleared
	iso_RESET_high();			//  "
	ROM_SSIDisable(SSI3_BASE);

	// Change the SSI pins to GPIO to reduce power consumption
	ROM_SysCtlPeripheralDisable(SYSCTL_PERIPH_SSI3);

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_0);		// SSI3CLK
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_0, 0x00);

	ROM_GPIOPinTypeGPIOInput(GPIO_PORTH_BASE, GPIO_PIN_2);		// SSI3Rx

	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_3);		// SSI3Tx
	ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_3, 0x00);

	iso_assert_CS();	// ADS1248 CS asserted low

	// Power down
	ROM_GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_2, 0x00);  	// Iso 3.3V power off
	ROM_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_4, 0x00);  	// Optoisolator power off
}

/*
 * pollADS1248_iso()
 * Returns the voltage between to two specified differential pins.
 * Sample averaging indicated by value of "trials".
 * Gain and data rate can be set for each channel.
 */
float pollADS1248_iso(unsigned char pos_chan, unsigned char neg_chan, int trials, int gain, int sps)
{
	long sample = 0, result;
	int i, byte;
	uint32_t mux0, vbias, mux1, sys0, data[10];

	// Write configuration data to MUX0, VBIAS, MUX1, and SYS0 in one transaction
	iso_assert_CS();							// Start SSI register write transaction

	mux0 = (pos_chan << 3) | neg_chan;			// MUX0 channel register
	vbias = 0;									// VBIAS register
	mux1 = 0x30;								// 2.048 V internal reference selected
	sys0 = ADS1248_gain_sps(gain, sps);			// SYS0 register. Sets gain and data rate

	while(ROM_SSIDataGetNonBlocking(SSI3_BASE, &data[0]));		// Flush receive FIFO

	ROM_SSIDataPutNonBlocking(SSI3_BASE, 0x40 + REG_MUX0);		// Start writing at MUX0
	ROM_SSIDataPutNonBlocking(SSI3_BASE, 3);					// Write 4 bytes (n-1)
	ROM_SSIDataPutNonBlocking(SSI3_BASE, mux0);
	ROM_SSIDataPutNonBlocking(SSI3_BASE, vbias);
	ROM_SSIDataPutNonBlocking(SSI3_BASE, mux1);
	ROM_SSIDataPutNonBlocking(SSI3_BASE, sys0);

	while(ROM_SSIBusy(SSI3_BASE));		// Let SSI finish sending bytes
	iso_deassert_CS();					// Finish SSI register write transaction

	// A/D is sampling continuously, so get as many samples as we need
	for(i = 0; i < trials; i++)
	{
		while( iso_DRDY() );										// Wait for conversion to complete
		while(ROM_SSIDataGetNonBlocking(SSI3_BASE, &data[0] ));		// Flush receive FIFO

		iso_assert_CS();									// Start SSI read transaction
		ROM_SSIDataPutNonBlocking(SSI3_BASE, NOP);			// Clock out result bytes
		ROM_SSIDataPutNonBlocking(SSI3_BASE, NOP);			// Clock out result bytes
		ROM_SSIDataPutNonBlocking(SSI3_BASE, NOP);			// Clock out result bytes
		while(ROM_SSIBusy(SSI3_BASE));						// Let SSI finish sending bytes

		for(byte=0; byte<3; byte++)	// Get the 24-bit result.
		{
			ROM_SSIDataGetNonBlocking(SSI3_BASE, &data[byte]);		// Read the result bytes
			data[byte] &= 0x00FF;									// Save only LSB
		}

		iso_deassert_CS();				// Finish SSI read transaction

		// Concatenate the 3 bytes of the 24 bit count
		result =  (data[0] << 16) | (data[1] << 8 ) | data[2];

		// Mask off MSB of 32 bit word
		result = 0x00FFFFFF & result;


		// Check to see if MSB is set (if MSB == 1, then we have a negative #, must convert appropriately)
		if( (result & 0x00800000) == 0x00800000 )
		{
			// Do the 2's complement conversion (we have a negative number)
			result = ~result;
			result = 0x007FFFFF & result;
			++result;
			result *= -1;
		}

		sample += result;
	}

	return ((float) (sample/trials/gain)) * COUNTSTOVOLTS;
}

/*
 * ADS1248_set_gain_sps()
 * Sets the PGA gain and data rate (samples per second).
 * Valid values for gain are: 1,2,4,8,16,32,64 and 128.
 * Valid values for data rate are: 5,10,20,40,80,160,320,640,1000 and 2000 sps.
 */
unsigned char ADS1248_gain_sps(int gain, int sps)
{
	unsigned char gain_sps;

	switch(gain)
	{
		case 1:
			gain = PGA_1;
			break;

		case 2:
			gain = PGA_2;
			break;

		case 4:
			gain = PGA_4;
			break;

		case 8:
			gain = PGA_8;
			break;

		case 16:
			gain = PGA_16;
			break;

		case 32:
			gain = PGA_32;
			break;

		case 64:
			gain = PGA_64;
			break;

		case 128:
			gain = PGA_128;
			break;

		default:
			uprintf("\n\nUnrecognized PGA gain. Setting to 1.");
			gain = PGA_1;
	}

	switch(sps)
	{
		case 5:
			sps = SPS_5;
			break;

		case 10:
			sps = SPS_10;
			break;

		case 20:
			sps = SPS_20;
			break;

		case 40:
			sps = SPS_40;
			break;

		case 80:
			sps = SPS_80;
			break;

		case 160:
			sps = SPS_160;
			break;

		case 320:
			sps = SPS_320;
			break;

		case 640:
			sps = SPS_640;
			break;

		case 1000:
			sps = SPS_1000;
			break;

		case 2000:
			sps = SPS_2000;
			break;

		default:
			uprintf("\n\nUnrecognized data rate. Setting to 5 sps.");
			sps = SPS_5;
	}

	gain_sps = gain | sps;	// Combine the two nibbles

	return gain_sps;
}
