/*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 */




#ifndef SEAFET_SEAPHOX_V2_0_ADS1248_NONISO_H_
#define SEAFET_SEAPHOX_V2_0_ADS1248_NONISO_H_

/*
 * To change the channels on the ADS1248.
 */
typedef enum
{
	ain1248_ni_0 = 0x0,
	ain1248_ni_1 = 0x1,
	ain1248_ni_2 = 0x2,
	ain1248_ni_3 = 0x3,
	ain1248_ni_4 = 0x4,
	ain1248_ni_5 = 0x5,
	ain1248_ni_6 = 0x6,
	ain1248_ni_7 = 0x7
}ain1248_ni_types;


/*
 * ADS1248.c function prototypes:
 */
void openADS1248_noniso(void);
float pollADS1248_noniso(unsigned char channel1, unsigned char channel2, int trials);
void closeADS1248_noniso(void);
signed long ADS1248GetValue_noniso(void);
void ADS1248ChangeChannel_noniso(unsigned char channel1, unsigned char channel2);

#endif /* ADS1248_H_ */
