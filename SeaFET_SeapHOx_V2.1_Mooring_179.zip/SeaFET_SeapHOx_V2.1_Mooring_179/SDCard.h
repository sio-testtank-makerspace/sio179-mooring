/*
 * David Muller; Germ�n Alfaro
 * davehmuller@gmail.com; alfaro.germanevera@gmail.com
 */


#ifndef SEAFET_SEAPHOX_V2_0_SDCARD_H_
#define SEAFET_SEAPHOX_V2_0_SDCARD_H_

#include "System.h"
#include "SDCard.h"
#include "IO.h"
#include "fatfs/src/diskio.h"
#include "fatfs/src/ff.h" 	// FRESULT is defined in this file
#include "utils/cmdline.h"


// SDCard.c function prototypes:
void Init_SDCard(void);
void closeSDCard(void);
void viewFiles(void);
void appendBufferToSDCard(char *buffer);
const char *StringFromFresult(FRESULT fresult);  //For decoding SD card error messages
int sd_fprintf(FIL *fil, const char *format, ...);

#endif /* SEAFET_SEAPHOX_V2_0_SDCARD_H_ */
